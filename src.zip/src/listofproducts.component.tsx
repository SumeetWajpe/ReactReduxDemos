import React, { Component } from 'react';
import ProductModel from './product.model';
import Product from './product.component';
import NewProduct from './newproduct.component';
import NewProductMuHooks from './newproductusingmutationhook';

export default class ListOfProducts extends Component<any,{}> {   
        static defaultProps = {
        allproducts:{products:[]}
    }
    constructor(props: any) {
        super(props);      
    }     
    render() {    
        console.log(this.props.allproducts) ;
        var allProductsToBeCreated = this.props.allproducts.products.map((p:ProductModel) => 
        <Product productdetails={p}
        key={p.id}
         />
        );
        return <div>
            <div className="jumbotron">
                <h1>Online Shopping</h1>
            </div>
            {/* <NewProduct /> */}
            <NewProductMuHooks />
            <div className="row">
                {allProductsToBeCreated}
                 {/* Array of <Product productdetails={p} /> */}
                {/* <Product /> */}
            </div>
        </div>
    }
}
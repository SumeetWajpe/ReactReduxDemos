import React from 'react';
import axios from 'axios';
// 1. install axios/jquery  [npm install axios --save]
// 2. use axios to make ajax request - ?
// 3. print the response in console.

export default class PostsComponent extends React.Component<{},any> {
    
    constructor(props:any){
        super(props);
        this.state = {allposts:[]};
    }
    componentDidMount(){
        // make ajax request !
      let thePromise =  axios.get('https://jsonplaceholder.typicode.com/posts')
      thePromise.then(
          (response)=>{               
                // setState !
                this.setState({allposts:response.data});
          },
          (err)=>{
              console.log(err);
          }
      )
    }
    render() {
        var allpoststoberendered  = this.state.allposts.map((p:any)=> <li> {p.title} </li>);
        return <div>
            <h1> All Posts </h1>
            {/* list of posts -> title */}
            <ul>
                {allpoststoberendered}
            </ul>
        </div>
    }
}
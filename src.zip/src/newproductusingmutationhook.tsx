import React, { useState } from "react";
import gql from "graphql-tag";
import { Mutation } from "react-apollo";
import {useMutation} from '@apollo/react-hooks';
import ProductModel from "./product.model";
import { Query } from 'react-apollo';

const ADD_PRODUCT = gql`
  mutation ProductMutation(
    $id: ID!
    $name: String!
    $likes: Int
    $imageUrl: String
    $price: Int!
    $quantity: Int
    $rating: Int
  ) {
    createProduct(
      id: $id
      name: $name
      likes: $likes
      imageUrl: $imageUrl
      price: $price
      quantity: $quantity
      rating: $rating
    ) {
      name
    }
  }
`;


const GET_ALL_PRODUCTS = gql`
  query{
    products{
      id,
      name,
      rating,
      likes,
      quantity,
      price,
      imageUrl
    }
  }
`
function NewProductMuHooks() {
  const [newProduct,setNewProduct] = useState({
    id: 0,
    name: "",
    likes: 0,
    quantity: 0,
    rating: 0,
    imageUrl: "",
    price: 0,
  });
  const [createProduct, { data }] = useMutation(ADD_PRODUCT,
    {refetchQueries:[{query:GET_ALL_PRODUCTS}]});


    var { id, name, likes, quantity, rating, imageUrl, price } = newProduct;

    return (
      <form>
          Id :{" "}
        <input
          type="number"
          id="text"
          onChange={(e) => setNewProduct({...newProduct, id: +(e.target.value) })}
        />{" "}
        <br />
        Name :{" "}
        <input
          type="text"
          id="text"
          onChange={(e) => setNewProduct({...newProduct, name: (e.target.value) })}

        />{" "}
        <br />
        Price :{" "}
        <input
          type="number"
          id="text"
          onChange={(e) => setNewProduct({...newProduct, price: +(e.target.value) })}

        />{" "}
        <br />
        likes :{" "}
        <input
          type="number"
          id="text"
          onChange={(e) => setNewProduct({...newProduct, likes: +(e.target.value) })}

        />{" "}
        <br />
        rating :{" "}
        <input
          type="number"
          id="text"
          onChange={(e) => setNewProduct({...newProduct, rating: +(e.target.value) })}

        />{" "}
        <br />
        quantity :{" "}
        <input
          type="number"
          id="text"
          onChange={(e) => setNewProduct({...newProduct, quantity: +(e.target.value) })}

        />{" "}
        <br />
        Image Url :{" "}
        <input
          type="text"
          id="text"
          onChange={(e) => setNewProduct({...newProduct, imageUrl: (e.target.value) })}

        />{" "}
        <br />
       
          
            <button
              className="btn btn-success"
              onClick={(e) => {
                e.preventDefault();
                console.log(newProduct);
                createProduct({variables:{...newProduct}});
              }}
            >
              <span className="glyphicon glyphicon-plus-sign"></span>
            </button>
       
      </form>
    );
  }

export default NewProductMuHooks;
import React from "react";
import gql from "graphql-tag";
import { Mutation } from "react-apollo";
import ProductModel from "./product.model";
import { Query } from 'react-apollo';

const ADD_PRODUCT = gql`
  mutation ProductMutation(
    $id: ID!
    $name: String!
    $likes: Int
    $imageUrl: String
    $price: Int!
    $quantity: Int
    $rating: Int
  ) {
    createProduct(
      id: $id
      name: $name
      likes: $likes
      imageUrl: $imageUrl
      price: $price
      quantity: $quantity
      rating: $rating
    ) {
      name
    }
  }
`;


const GET_ALL_PRODUCTS = gql`
  query{
    products{
      id,
      name,
      rating,
      likes,
      quantity,
      price,
      imageUrl
    }
  }
`

export default class NewProduct extends React.Component {
  state: any = {
    id: 6,
    name: "",
    likes: 0,
    quantity: 0,
    rating: 0,
    imageUrl: "",
    price: 0,
  };

  render() {
    var { id, name, likes, quantity, rating, imageUrl, price } = this.state;

    return (
      <form>
          Id :{" "}
        <input
          type="number"
          id="text"
          onChange={(e) => this.setState({ id: +(e.target.value) })}
        />{" "}
        <br />
        Name :{" "}
        <input
          type="text"
          id="text"
          onChange={(e) => this.setState({ name: e.target.value })}
        />{" "}
        <br />
        Price :{" "}
        <input
          type="number"
          id="text"
          onChange={(e) => this.setState({ price: +e.target.value })}
        />{" "}
        <br />
        likes :{" "}
        <input
          type="number"
          id="text"
          onChange={(e) => this.setState({ likes: +e.target.value })}
        />{" "}
        <br />
        rating :{" "}
        <input
          type="number"
          id="text"
          onChange={(e) => this.setState({ rating: +e.target.value })}
        />{" "}
        <br />
        quantity :{" "}
        <input
          type="number"
          id="text"
          onChange={(e) => this.setState({ quantity: +e.target.value })}
        />{" "}
        <br />
        Image Url :{" "}
        <input
          type="text"
          id="text"
          onChange={(e) => this.setState({ imageUrl: e.target.value })}
        />{" "}
        <br />
        <Mutation
          mutation={ADD_PRODUCT}
          refetchQueries={[{query:GET_ALL_PRODUCTS}]}          
          variables={{ id, name, likes, imageUrl, price, quantity, rating }}
        //   update={(cache:any, { data: { createProduct } }:any) => {
        //     const { products } = cache.readQuery({ query: GET_ALL_PRODUCTS });
        //     cache.writeQuery({
        //       query: GET_ALL_PRODUCTS,
        //       data: { products: products.concat([createProduct]) },
        //     });
        //   }}
        >
          {(createProduct: any) => (
            <button
              className="btn btn-success"
              onClick={(e) => {
                e.preventDefault();
                createProduct();
              }}
            >
              <span className="glyphicon glyphicon-plus-sign"></span>
            </button>
          )}
        </Mutation>
      </form>
    );
  }
}

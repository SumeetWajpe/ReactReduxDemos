import React from 'react';
import logo from './logo.svg';
import './App.css';
import ListOfCoursesComponent from './listofcourses.component';

class App extends React.Component {
  render() {
    return <React.Fragment>
      <div className="jumbotron">
        <h1> Online Courses</h1>
      </div>
      <ListOfCoursesComponent />
    </React.Fragment>
  }
}
export default App;

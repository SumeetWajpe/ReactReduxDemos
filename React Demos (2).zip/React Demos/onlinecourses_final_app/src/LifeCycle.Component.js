import React from 'react';

export default class LifeCycleMethods extends React.Component{
   
    constructor(props){
        super(props);    
        console.log('Within Constructor !');
        this.state = {companyname:''};    
    }   
    componentWillMount(){
        console.log('Within componentWillMount !');
    }
    componentDidMount(){
        console.log('Within componentDidMount !');
    }
    // stop from unneccessary rerenders !
    shouldComponentUpdate(){
        console.log('Within shouldComponentUpdate !');
        console.log(this.state.companyname);
        return true;// biz logic !
    }
    componentWillUpdate(){
        console.log('Within componentWillUpdate !');
    }
    componentDidUpdate(){
         console.log('Within componentDidUpdate !');
    }

    ChangeHandler(){
        // change the innerHTML of h2
        console.log('Within ChangeHandler !');
        this.setState({companyname:this.refs.txtCompany.value});
    }
    render(){
        console.log('Within render !');     
        console.log(this.state.companyname);

            return <div>
                Company Name : <input type="text" 
                ref="txtCompany"
                onChange={this.ChangeHandler.bind(this)} />
                <h2>{this.state.companyname}</h2>
            </div>
    }
}
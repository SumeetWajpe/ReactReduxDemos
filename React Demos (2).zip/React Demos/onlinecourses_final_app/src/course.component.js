import React from 'react';

export default class CourseComponent extends React.Component{
      constructor(props){
         // console.log('Constructor !');
        super(props);
        this.state = {count:this.props.coursedetails.likes};
    }

    IncrementLikes(){
       // console.log('IncrementLikes !');

            this.setState({count:this.state.count+1})
    }
    componentWillUnmount(){
        console.log('Any clean Up code !')
    }
    render(){
        //console.log('Render !');
        return  <div className="col-md-4">   
                        <div className="row">
                            <div className="col-md-8">
                            <h2> {this.props.coursedetails.name} </h2>
                            </div>
                            <div className="col-md-4">
                                <button className="btn btn-danger" 
                                onClick={this.props.ParentHandler.bind(this,
                                this.props.coursedetails.id)}>
                                    <span className="glyphicon glyphicon-trash">
                                    </span>
                                </button>
                            </div>
                        </div>             
                     <img src={this.props.coursedetails.ImageUrl} height="200px" width="200px"/> <br/>
                    <b>Duration : </b> {this.props.coursedetails.duration} <br/>
                    <b>Price : </b>{this.props.coursedetails.price}<br/>
                    <b>Rating : </b> {this.props.coursedetails.rating}<br/>
                    <b>Location : </b> {this.props.coursedetails.location} <br/>
                    <button className="btn btn-primary btn-lg" onClick={this.IncrementLikes.bind(this)}>
                        <span className="glyphicon glyphicon-thumbs-up">

                        </span>
                    {this.state.count}
                    </button>
                </div> 
    }
}

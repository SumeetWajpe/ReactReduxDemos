import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Route, Switch, Link } from 'react-router-dom';

import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import LifeCycleMethods from './LifeCycle.Component';
import { Posts } from './posts.component';
import PostDetails from './postdetails.component';


var MyRoutes = <React.Fragment>
    <BrowserRouter>
    <nav className="navbar navbar-inverse">
  <div className="container-fluid">
    <div className="navbar-header">
      <Link className="navbar-brand" to="/">Online Courses</Link>
    </div>
    <ul className="nav navbar-nav">
      <li ><Link to="/">Home </Link></li>
      <li><Link to="/posts"> Posts </Link></li>      
    </ul>
  </div>
</nav>
        <Route path="/" exact component={App}></Route>
        <Route path="/posts" component={Posts}></Route>
        <Route path="/postdetails/:id" component={PostDetails}></Route>

    </BrowserRouter>
</React.Fragment>
// ReactDOM.render(<App />, document.getElementById('root'));
// ReactDOM.render(<LifeCycleMethods />, document.getElementById('root'));
//ReactDOM.render(<Posts />, document.getElementById('root'));

ReactDOM.render(MyRoutes, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();

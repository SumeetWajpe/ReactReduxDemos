import React from 'react';
import CourseComponent from './course.component';

export default class ListOfCoursesComponent extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            courses :[
                {id:1,name:"Typescript",duration:'2 Days',rating:5,price:5000,likes:400,ImageUrl:"https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2Fmspoweruser.com%2Fwp-content%2Fuploads%2F2016%2F07%2Ftypescript-cover-image.jpg&f=1",location:'Pune'},
                {id:2,name:"Angular",duration:'3 Days',rating:4,price:4000,likes:400,ImageUrl:"https://proxy.duckduckgo.com/iu/?u=https%3A%2F%2Fjaxenter.com%2Fwp-content%2Fuploads%2F2016%2F01%2Fshutterstock_229869889.jpg&f=1",location:'Pune'},
                {id:3,name:"Vue",duration:'3 Days',rating:4.678,price:8000,likes:300,ImageUrl:"https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2Fwww.programwitherik.com%2Fcontent%2Fimages%2F2017%2F01%2F87ow.png&f=1",location:'Hyderabad'},
                {id:4,name:"Redux",duration:'2 Days',rating:3,price:6000,likes:200,ImageUrl:"https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2Fblog.js-republic.com%2Fwp-content%2Fuploads%2F2016%2F11%2Flogo-redux.png&f=1",location:'Mumbai'},
                {id:5,name:"React",duration:'2 Days',rating:4,price:5000,likes:100,ImageUrl:"https://proxy.duckduckgo.com/iu/?u=http%3A%2F%2Fwww.valuecoders.com%2Fblog%2Fwp-content%2Fuploads%2F2016%2F08%2Freact.png&f=1",location:'Bengaluru'}    
              ] 
        }
    }
      DeleteACourse_Parent(theId){
        var newCourseList = this.state.courses.filter(c => c.id !== theId);
        this.setState({courses:newCourseList});
    }  
    render(){
            var coursesToBeCreated = this.state.courses.map(c=>
            <CourseComponent 
                coursedetails={c} 
                key={c.id}
                ParentHandler=
                {this.DeleteACourse_Parent.bind(this)}
                />);

        return <div className="row">
                    {coursesToBeCreated}
        </div>
    }
}
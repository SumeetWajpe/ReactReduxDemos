import React from 'react';

// export default class PostDetails extends React.Component{
//     render(){
//         const {params} = this.props.match;
//          return <h1> Post Details for {params.id}</h1>
//     }
// }

var  PostDetails= (props) =>{
    return <h1> Post Details for {props.match.params.id} !</h1>
}

export default PostDetails;

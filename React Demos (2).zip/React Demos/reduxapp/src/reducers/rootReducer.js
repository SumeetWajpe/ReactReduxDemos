import { combineReducers } from "redux";
import posts from './postsreducer';
import products from './productsreducer';

export var rootReducer = combineReducers({
    posts,products
});

// var city = "Pune",title="Harman";

// var company = {title,city}
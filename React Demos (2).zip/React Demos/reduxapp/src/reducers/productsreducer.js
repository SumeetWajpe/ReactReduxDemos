export default function products(defStore = [], action) {
    let theIndex ;
    switch (action.type) {
        case 'INCREMENT_LIKES':

            theIndex = defStore.findIndex(p => p.id === 
                action.prodId);
           
                    return [
                        ...defStore.slice(0,theIndex),
                        {...defStore[theIndex],likes:defStore[theIndex].likes + 1},
                        ...defStore.slice(theIndex+1)
                    ];

        case 'DELETE_PRODUCT':                
        theIndex = defStore.findIndex(p => p.id === 
            action.prodId);
                        return [
                            ...defStore.slice(0,theIndex),
                             ...defStore.slice(theIndex+1)
                        ];
    
         case 'FETCH_PRODUCTS':
            //  console.log('Within Fetch Products Reducer !')
             return action.productlist;
        default:
            return defStore;   
    }
}
import React from 'react'

export const Product = (props) => {
    return(
        <div className="col-md-4 productStyle">
            <div className="row">
                <div className="col-md-9">
                        <h3> {props.prodDetails.title}  </h3>    
                </div>
                <div className="col-md-3">
                    <button className="btn btn-danger" onClick={props.DeleteProduct.bind(null,props.prodDetails.id)}>
                        <span className="glyphicon glyphicon-trash"></span>
                    </button>
                </div>
            </div>
            <div className="row">
                <div className="col-md-4">
                        <img height="100px" width="100px" src={props.prodDetails.ImageUrl} />
                </div>
                <div className="col-md-8">
                        
                        <h4>Rating : {props.prodDetails.rating}</h4>
                        <h4>Price : {props.prodDetails.price}</h4>
                        <h4>Quantity : {props.prodDetails.quantity}</h4>

                </div>
            </div>
            <div className="row">
                    <div className="col-md-12">
                        <button className="btn btn-primary"
                         onClick={props.IncrementLikes.bind(null,props.prodDetails.id)}>
                            {props.prodDetails.likes}
                                <span className="glyphicon glyphicon-thumbs-up">

                                </span>
                        </button>
                    </div>
            </div>
        </div>
    )
}

export default Product
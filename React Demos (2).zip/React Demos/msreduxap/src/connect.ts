import{connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import * as allactions from './actions/actioncreators';
import App from './components/App';

//exposes store data as props to react component
function mapStateToProps(storeDataFromProvider:any){
        return{
            allproducts:storeDataFromProvider.products,
            allusers:storeDataFromProvider.users
        }
    }
// exposes action creators as props (also bind with dispatcher)
function mapDispatchProps(dispatcherObj:any){
    return   bindActionCreators(allactions,dispatcherObj)
}
export var HOCApp = connect(mapStateToProps,mapDispatchProps)(App);
import {products} from './products.reducer';
import { users } from "./users.reducer";
import {combineReducers} from 'redux';

export var rootReducer = combineReducers({
    products,users
});

export function products(defStore:any= [],action:any) {
    switch (action.type) {
        case 'INCREMENT_PRODUCT_LIKES':            
            console.log('Within INCREMENT_PRODUCT_LIKES');
            let index = defStore.findIndex((p:any)=>p.id == action.theProductId)
            return [
                ...defStore.slice(0,index),
                {...defStore[index],likes:defStore[index].likes+1},
                ...defStore.slice(index+1)
            ];             //return  updated Store !
        case 'DELETE_PRODUCT':            
                console.log('Within DELETE_PRODUCT');
                return defStore; //return  updated Store !   
                case 'FETCH_PRODUCTS':
                    return action.response;// updated Store data     
        default:
            return defStore;
    }
}
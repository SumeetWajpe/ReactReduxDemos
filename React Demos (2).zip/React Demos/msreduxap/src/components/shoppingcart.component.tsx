import React from 'react'
import ProductComponent from './product.component';

export const ShoppingCart = (props:any) => {
    
    var allproductstobecreated = props.allproducts.map((p:any)=><ProductComponent key={p.id} prodDetails={p} {...props}/>)

    return(
       <div>
           {allproductstobecreated}
       </div>
    )
}

export default ShoppingCart
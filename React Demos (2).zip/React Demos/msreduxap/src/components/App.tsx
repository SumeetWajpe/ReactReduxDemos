import React from 'react';
import logo from './logo.svg';
import '../components/App.css'
import ShoppingCart from './shoppingcart.component';

class App extends React.Component<any, any> {
  componentDidMount(){
    this.props.FetchProducts(); 
  }
  render() {
    return <div className="App">
                  <ShoppingCart {...this.props}></ShoppingCart>
               </div>
  }
}
export default App;

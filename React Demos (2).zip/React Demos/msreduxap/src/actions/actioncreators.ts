import  axios  from 'axios';

const INCREMENT_PRODUCT_LIKES = 'INCREMENT_PRODUCT_LIKES';
const DELETE_PRODUCT = 'DELETE_PRODUCT';
const ADD_USER = 'ADD_USER';

export function IncrementProductlikes(theProductId:number){
    return {type:INCREMENT_PRODUCT_LIKES,theProductId};
}

export function DeleteProduct(){
    return {type:DELETE_PRODUCT};
}

export function AddUser(){
    return {type:ADD_USER};
}

export function FetchProducts(){
    // logic for ajax request ! 
    // rxjs | axios   
   return (dispatch:any) => {
        axios.get('https://api.myjson.com/bins/73yat').then(
            (responseObj)=>{
                // console.log(responseObj.data);
                //dispatch an action
                dispatch({type:'FETCH_PRODUCTS',response:responseObj.data})
            },
            (err)=>{
                    console.log(err);
            }
    )
      };
    
}
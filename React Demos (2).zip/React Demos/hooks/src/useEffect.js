import React, { useState, useEffect } from 'react';
import axios from "axios";
 const App = () => {
    const [todo, setTodo] = useState("Please wait... Fetching Todo from server..");
    useEffect(() => {
        axios("https://api.myjson.com/bins/vagnn", {
            headers: {
                "Accept": "application/json"
            }
        }).then(res => setTodo(res.data.todo));
    }, []);
    return (<div className="jumbotron"><h1>"{todo}"</h1></div>);
}
export default App;
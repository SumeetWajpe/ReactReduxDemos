import React, { Component } from 'react';
class ShoppingCart extends Component {
  state = {    likes: 100  }
  render() {
    return (
      <div className="container">
        <h1>Shopping Cart</h1>
        <Product likes={this.state.likes} />
      </div>
    )
  }
}
class Product extends Component {
  render() {
    return (
      <div>
        <h1>Product</h1>
        <Likes likes={this.props.likes} />
      </div>
    )
  }
}
class Likes extends Component {
  render() {
    return (
      <div >
        <h1>Likes</h1>
        <button className="btn btn-primary">
          {this.props.likes}
          <span className="glyphicon glyphicon-thumbs-up">

          </span>
        </button>
      </div>
    )
  }
}

export default ShoppingCart;